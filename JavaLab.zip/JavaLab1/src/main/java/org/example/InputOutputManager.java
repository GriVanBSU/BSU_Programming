package org.example;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;
import static org.example.ArithmeticSolver.algorithmChoice;
import static org.example.ListOfExpressionXML.processXMLFile;

public class InputOutputManager {

    public static void processFile(Scanner scanner, String choice, String outputFile) {
        System.out.println("Введите имя файла: ");
        String textFileName = scanner.nextLine();
        System.out.println("Введите расширение файла: ");
        String textFileExtension = scanner.nextLine();
        String textFilePath = textFileName + "." + textFileExtension;

        try {
            if (textFileExtension.equals("txt")) {
                textFile.processTextFile(textFilePath, outputFile, choice);
            } else if (textFileExtension.equals("json")) {
                JsonSimpleParser parser = new JsonSimpleParser();
                Root root = parser.parse(textFilePath, choice);
            }else if(textFileExtension.equals("xml")) {
                processXMLFile(textFilePath, outputFile, choice);
            } else {
                System.out.println("Неподдерживаемый формат файла");
                return;
            }

            UnzipFile.archiveZIP(outputFile);
        } catch (Exception e) {
            System.out.println("Error with files: " + e.getMessage());
        }
    }

    public static void processArchivedFile(Scanner scanner, String choice, String outputFile) {
        System.out.println("Введите имя архива(без расширения): ");
        String archiveFileName = scanner.nextLine();
        System.out.println("Введите расширение архива: ");
        String archiveFileExtension = scanner.nextLine();
        String archiveFilePath = archiveFileName + "." + archiveFileExtension;

        System.out.println("Введите имя файла: ");
        String textFileName = scanner.nextLine();
        System.out.println("Введите расширение файла: ");
        String textFileExtension = scanner.nextLine();
        String textFilePath = textFileName + "." + textFileExtension;

        try {
            File archiveFile = new File(archiveFilePath);
            FileInputStream archiveInput = new FileInputStream(archiveFile);
            byte[] archiveBytes = new byte[(int) archiveFile.length()];
            archiveInput.read(archiveBytes);
            archiveInput.close();

            File textFile = UnzipFile.unzip(archiveFilePath, textFilePath);

            FileInputStream textInput = new FileInputStream(textFile);
            byte[] textBytes = textInput.readAllBytes();
            textInput.close();

            Files.write(Paths.get("myfile.txt"), textBytes);
            BufferedReader reader = new BufferedReader(new FileReader("myfile.txt"));
            String expression = reader.readLine();
            FileWriter outputWriter = new FileWriter("output.txt");

            while (expression != null) {
                double result = algorithmChoice(expression, choice);
                outputWriter.write(Double.toString(result) + "\n");
                expression = reader.readLine();
            }

            reader.close();
            outputWriter.close();

            UnzipFile.archiveZIP(outputFile);
        } catch (Exception e) {
            System.out.println("Error with files: " + e.getMessage());
        }
    }

    public static void formatOfOutputFileChoice(){

    }
}
