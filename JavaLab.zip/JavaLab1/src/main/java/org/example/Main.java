package org.example;
import java.util.Scanner;
import static org.example.InputOutputManager.processArchivedFile;
import static org.example.InputOutputManager.processFile;

public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите свойства вашего файла из списка: ");
        System.out.println("Файл");
        System.out.println("Архивированный файл");
        System.out.println("Зашифрованный файл");
        System.out.println("Файл зашифрован и находится в архиве");
        String userAnswer = scanner.nextLine();
        String outputFile = "output.txt";

        System.out.println("Введите имя алгоритма, которым хотите решить задачи:");
        System.out.println("regular - Использовать регулярные выражения.");
        System.out.println("line - Не испольуя регулярные выражения.");
        System.out.println("library - Решение через библиотеку  exp4j");
        String choice = scanner.nextLine();

        if (userAnswer.equals("Файл")) {
            processFile(scanner, choice, outputFile);
        } else if (userAnswer.equals("Архивированный файл")) {
            processArchivedFile(scanner, choice, outputFile);
        } else if(userAnswer.equals("Зашифрованный файл")){

        }else if(userAnswer.equals("Файл зашифрован и находится в архиве")){

        }else{
            System.out.println("Invalid input : ");
            return;
        }

    }
}