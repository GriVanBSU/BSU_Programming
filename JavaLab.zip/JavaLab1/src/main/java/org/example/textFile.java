package org.example;
import java.io.*;

public class textFile {

    public static void processTextFile(String inputFile, String outputFile, String choice) {
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {

            String expression;
            while ((expression = reader.readLine()) != null) {
                double result = ArithmeticSolver.algorithmChoice(expression, choice);
                writer.write(Double.toString(result) + "\n");
            }
        } catch (IOException e) {
            System.out.println("Error with files: " + e.getMessage());
        }
    }
}