package org.example;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Root{

    private List<ListOfExpressionXML> arithmeticSolver;
    public List<ListOfExpressionXML> getArithmeticSolver() {return arithmeticSolver;}

    public void setArithmeticSolver(List<ListOfExpressionXML> arithmeticSolver) {
        this.arithmeticSolver = arithmeticSolver;
    }

    public static Document buildDocument(String inputFile) throws Exception{
        File file = new File(inputFile);
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        return documentBuilderFactory.newDocumentBuilder().parse(file);
    }

    @Override
    public String toString() {
        return "Root{" +
                "arithmeticSolver=" + arithmeticSolver +
                '}';
    }
}