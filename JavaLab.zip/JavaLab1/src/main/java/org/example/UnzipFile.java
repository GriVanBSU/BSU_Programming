package org.example;
import java.io.*;
import java.util.Scanner;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

public class UnzipFile {
    public static void archiveZIP(String sourceFile) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Желаете заархивировать Ваш файл вывода?(yes/no) : ");
        String yesNoAnswer = scanner.nextLine();

        if (yesNoAnswer.equals("yes")) {
            System.out.println("Введите имя архива, в который хотите поместить файл");
            String archiveName = scanner.nextLine();
            try (FileOutputStream fos = new FileOutputStream(archiveName);
                 ZipOutputStream zos = new ZipOutputStream(fos);
                 FileInputStream fis = new FileInputStream(sourceFile)) {
                File file = new File(sourceFile);
                ZipEntry zipEntry = new ZipEntry(file.getName());
                zos.putNextEntry(zipEntry);

                byte[] buffer = new byte[1024];
                int length;
                while ((length = fis.read(buffer)) > 0) {
                    zos.write(buffer, 0, length);
                }

                zos.closeEntry();
                System.out.println("Файл успешно заархивирован! В архиве с именем " + archiveName + " находится файл результатов подсчёта");
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else if (yesNoAnswer.equals("no")) {}
        else {System.out.println("Invalid input....");}
    }

    public static File unzip(String archiveFile, String outputFilePath) throws IOException {
        File destFile = new File(outputFilePath);
        try (ZipInputStream zipInputStream = new ZipInputStream(new FileInputStream(archiveFile))) {
            byte[] buffer = new byte[1024];
            ZipEntry zipEntry = zipInputStream.getNextEntry();
            if (zipEntry != null) {
                File outputFile = new File(destFile.getParent(), zipEntry.getName());
                try (FileOutputStream fileOutputStream = new FileOutputStream(outputFile)) {
                    int len;
                    while ((len = zipInputStream.read(buffer)) > 0) {
                        fileOutputStream.write(buffer, 0, len);
                    }
                }
                return outputFile;
            }
        }
        return null;
    }


}