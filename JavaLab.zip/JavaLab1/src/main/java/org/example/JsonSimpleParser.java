package org.example;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class JsonSimpleParser {

    private static final String TAG_EXPRESSIONS = "expressions";
    private static final String TAG_EXPRESSION = "expression";

    public Root parse(String inputFile, String choice) {
        Root root = new Root();
        JSONParser parser = new JSONParser();
        try (FileReader reader = new FileReader("input.json")) {
            JSONObject rootJsonObject = (JSONObject) parser.parse(reader);
            JSONArray expressionJsonArray = (JSONArray) rootJsonObject.get(TAG_EXPRESSIONS);

            List<ListOfExpressionXML> expressionList = new ArrayList<>();
            for (Object item : expressionJsonArray) {
                JSONObject expressionJsonObject = (JSONObject) item;
                String expression = (String) expressionJsonObject.get(TAG_EXPRESSION);
                ListOfExpressionXML lst = new ListOfExpressionXML(expression);
                expressionList.add(lst);
            }

            root.setArithmeticSolver(expressionList);
            Scanner scanner = new Scanner(System.in);
            System.out.println("Введите формата файла вывода(txt, json, xml):");
            String outputFormChoice = scanner.nextLine();
            if(outputFormChoice.equals("txt")){
                try (BufferedReader Reader = new BufferedReader(new FileReader(inputFile));
                     BufferedWriter writer = new BufferedWriter(new FileWriter("output1.txt"))) {

                    for (ListOfExpressionXML expression : expressionList) {
                        String lineForSolver = expression.getLine();
                        double result = ArithmeticSolver.algorithmChoice(lineForSolver, choice);
                        writer.write(Double.toString(result) + "\n");
                    }
                } catch (IOException e) {
                    System.out.println("Error with files: " + e.getMessage());
                }
            }else if(outputFormChoice.equals("json")){
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("output.json"))) {
                    JSONArray resultJsonArray = new JSONArray();
                    for (ListOfExpressionXML expression : expressionList) {
                        String lineForSolver = expression.getLine();
                        double result = ArithmeticSolver.algorithmChoice(lineForSolver, choice);
                        resultJsonArray.add(result);
                    }
                    JSONObject outputJsonObject = new JSONObject();
                    outputJsonObject.put("results", resultJsonArray);
                    writer.write(outputJsonObject.toJSONString());
                } catch (IOException e) {
                    System.out.println("Error with files: " + e.getMessage());
                }
            }else if(outputFormChoice.equals("xml")){
                try (BufferedWriter writer = new BufferedWriter(new FileWriter("output.xml"))) {
                    DocumentBuilderFactory documentFactory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder documentBuilder = documentFactory.newDocumentBuilder();

                    Document document = documentBuilder.newDocument();
                    Element rootElement = document.createElement("results");
                    document.appendChild(rootElement);

                    for (ListOfExpressionXML expression : expressionList) {
                        String lineForSolver = expression.getLine();
                        double result = ArithmeticSolver.algorithmChoice(lineForSolver, choice);

                        Element resultElement = document.createElement("result");
                        resultElement.appendChild(document.createTextNode(String.valueOf(result)));
                        rootElement.appendChild(resultElement);
                    }

                    TransformerFactory transformerFactory = TransformerFactory.newInstance();
                    Transformer transformer = transformerFactory.newTransformer();
                    transformer.setOutputProperty(OutputKeys.INDENT, "yes");
                    transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");

                    DOMSource domSource = new DOMSource(document);
                    StreamResult streamResult = new StreamResult(new File("output.xml"));

                    transformer.transform(domSource, streamResult);
                } catch (IOException e) {
                    System.out.println("Error with files: " + e.getMessage());
                } catch (ParserConfigurationException | TransformerException e) {
                    System.out.println("Error creating XML file: " + e.getMessage());
                }
            }else{
                System.out.println("Invalid input... ");
                return null;
            }

            System.out.println(root.toString());
            return root;
        } catch (Exception e) {
            System.out.println("Parsing Error : " + e.toString());
        }

        return null;
    }
}