package org.example;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ListOfExpressionXML {

    public String getLine() {return line;}
    private String line;
    public ListOfExpressionXML(String line) {
        this.line = line;
    }

    public static void processXMLFile(String inputFile, String outputFile, String choice){
        Root root = new Root();
        Document document;
        try {
            document = Root.buildDocument(inputFile);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Error with file : " + e.toString());
            return;
        }

        Node rootNode = document.getFirstChild();
        NodeList rootChildren = rootNode.getChildNodes();

        Node arithmeticSolverNode = null;
        for (int i = 0; i < rootChildren.getLength(); i++) {
            Node childNode = rootChildren.item(i);
            if (childNode.getNodeType() != Node.ELEMENT_NODE) {
                continue;
            }

            if (childNode.getNodeName().equals("ArithmeticSolver")) {
                arithmeticSolverNode = childNode;
                break;
            }
        }

        if (arithmeticSolverNode == null) {
            return;
        }

        List<ListOfExpressionXML> expList = new ArrayList<>();
        NodeList expressionNodes = arithmeticSolverNode.getChildNodes();
        for (int i = 0; i < expressionNodes.getLength(); i++) {
            Node expressionNode = expressionNodes.item(i);
            if (expressionNode.getNodeType() != Node.ELEMENT_NODE) {
                continue;
            }

            if (expressionNode.getNodeName().equals("expression")) {
                NodeList lineNodes = expressionNode.getChildNodes();
                for (int j = 0; j < lineNodes.getLength(); j++) {
                    Node lineNode = lineNodes.item(j);
                    if (lineNode.getNodeType() != Node.ELEMENT_NODE) {
                        continue;
                    }

                    if (lineNode.getNodeName().equals("line")) {
                        String lineForSolver = lineNode.getTextContent();
                        ListOfExpressionXML lst = new ListOfExpressionXML(lineForSolver);
                        expList.add(lst);
                        break;
                    }
                }
            }
        }

        root.setArithmeticSolver(expList);

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {

            for (ListOfExpressionXML expression : expList) {
                String lineForSolver = expression.getLine();
                double result = ArithmeticSolver.algorithmChoice(lineForSolver, choice);
                writer.write(Double.toString(result) + "\n");
            }
        } catch (IOException e) {
            System.out.println("Error with files: " + e.getMessage());
        }

        System.out.println(root.toString());
    }

    @Override
    public String toString() {
        return "ListOfExpressionXML{" +
                "line='" + line + '\'' +
                '}';
    }
}
