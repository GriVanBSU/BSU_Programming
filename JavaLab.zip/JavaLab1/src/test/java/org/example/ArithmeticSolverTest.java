package org.example;

import org.example.ArithmeticSolver;

import static org.junit.jupiter.api.Assertions.*;
class ArithmeticSolverTest {
    @org.junit.jupiter.api.Test
    void solveTest() {
        ArithmeticSolver solver = new ArithmeticSolver();
        double result = solver.solve("2 + 5 - 4");
        assertEquals(3.0, result, 0.0001);

        result = solver.solve(" (3 + 4) * 7");
        assertEquals(49.0, result, 0.0001);

        result = solver.solve(" ((3 + 4) * 3) + 7");
        assertEquals(28.0, result, 0.0001);

        result = solver.solve(" ((10 + 4) * 3) / 5");
        assertEquals(8.4, result, 0.0001);
    }

    @org.junit.jupiter.api.Test
    void solveRegexTest(){
        ArithmeticSolver solver = new ArithmeticSolver();
        double result = solver.regexSolve("2 + 5 - 4");
        assertEquals(3.0, result, 0.0001);

        result = solver.regexSolve(" (3 + 4) * 7");
        assertEquals(49.0, result, 0.0001);

        result = solver.regexSolve(" ((3 + 4) * 3) + 7");
        assertEquals(28.0, result, 0.0001);

        result = solver.regexSolve(" ((10 + 4) * 3) / 5");
        assertEquals(8.4, result, 0.0001);
    }
}