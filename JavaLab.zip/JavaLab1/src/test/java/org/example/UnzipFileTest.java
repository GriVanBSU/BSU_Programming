package org.example;

import org.example.UnzipFile;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.io.File;
import java.io.IOException;

public class UnzipFileTest {

    @Test
    public void testArchiveZIP() {
        String sourceFile = "output.txt";
        String zipFile = "info.zip";

        UnzipFile.archiveZIP("output.txt");

        File zip = new File(zipFile);
        Assertions.assertTrue(zip.exists());
    }

    @Test
    public void testUnzip() throws IOException {
        String archiveFile = "info.zip";
        String outputFilePath = "info.txt";

        File unzippedFile = UnzipFile.unzip(archiveFile, outputFilePath);

        Assertions.assertTrue(unzippedFile.exists());
    }
}